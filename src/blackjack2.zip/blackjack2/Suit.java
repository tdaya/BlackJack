/*
 an enum is like an int, but instead of number I can name it other 
an enum represents the four possibilites of suits for a card
*/

package blackjack2;
 
public enum Suit {          //allows me to have atype called suit that allows me to take on one of the four different values 
    Clubs, 
    Diamonds, 
    Spades,
    Hearts;
}
